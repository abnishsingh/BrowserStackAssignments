package com.ncb.poc.ra.dao;

public class TestStep {
        private String description;

        public TestStep(String description) {
            this.description = description;
        }

        public String getDescription() {
            return description;
        }
    }