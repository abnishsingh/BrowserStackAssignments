package com.ncb.poc.ra.utils;


import com.ncb.poc.ra.config.Config;
import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;

public class Debug {

    private static final Logger logger = LogManager.getLogger(Debug.class);
    public static void main(String[] args) {
        System.out.println("Testing...");
        logger.info("Test Cycle Hello: {}", 1);
    }
}
