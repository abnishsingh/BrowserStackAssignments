package com.ncb.poc.ra.config;

import java.text.SimpleDateFormat;
import java.util.Date;

public class Config {
    public static final String CSV_FILE_PATH = ConfigReader.getProperty("CSV_FILE_PATH");
    public static final String AUTH_HEADER = ConfigReader.getProperty("AUTH_HEADER");
    public static final String BASE_URL = ConfigReader.getProperty("BASE_URL");
    public static final String SET_KEY = ConfigReader.getProperty("SET_KEY");
    public static final String CYCLE_NAME = ConfigReader.getProperty("CYCLE_NAME");
    public static String TIMESTAMP = new SimpleDateFormat("yyyyMMddHHmmss").format(new Date());
}