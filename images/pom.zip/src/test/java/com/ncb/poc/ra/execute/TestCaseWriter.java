package com.ncb.poc.ra.execute;

import com.ncb.poc.ra.config.Config;
import com.ncb.poc.ra.dao.TestCase;
import com.ncb.poc.ra.dao.TestStep;
import com.opencsv.CSVWriter;
import io.restassured.RestAssured;
import io.restassured.response.Response;
import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;
import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;

import java.io.File;
import java.io.FileWriter;
import java.io.IOException;
import java.util.ArrayList;
import java.util.List;

public class TestCaseWriter {

    private static final Logger logger = LogManager.getLogger(TestCaseWriter.class);

    public void processTestCases() throws JSONException {
        List<TestCase> testCases = fetchTestCases();
        List<String[]> csvData = new ArrayList<>();
        csvData.add(new String[]{"TestCaseKey", "TestName", "URL", "MethodType", "RequestHeader", "RequestBody", "ExpectedStatusCode", "ResponseBody"});
        for (TestCase testCase : testCases) {
            List<TestStep> testSteps = fetchTestSteps(testCase.getId());
            if (!testSteps.isEmpty()) { // Only process test cases with "restapi" tag
                csvData.add(extractTestCaseData(testCase, testSteps));
            }
        }
        writeDataToCSV(csvData);
    }

    private List<TestCase> fetchTestCases() {
        List<TestCase> testCases = new ArrayList<>();
        RestAssured.baseURI = Config.BASE_URL;
        // Set headers
        Response response = RestAssured.given()
                .header("Authorization", Config.AUTH_HEADER)
                .when()
                .get("/testcase")
                .then()
                .extract()
                .response();

        // Print the raw response to help debug the issue
        String responseBody = response.asString();
        logger.info("Testcases: {}", responseBody);
        try {
            JSONObject jsonResponse = new JSONObject(responseBody);
            JSONArray items = jsonResponse.getJSONArray("items");
            for (int i = 0; i < items.length(); i++) {
                JSONObject item = items.getJSONObject(i);
                String testcaseKey = item.getString("key");
                String title = item.getString("title");
                String description = item.isNull("description") ? "No Description" : item.getString("description");
                int id = item.getInt("ID");
                testCases.add(new TestCase(id, testcaseKey, title, description, false)); // Add ID to TestCase object
            }
        } catch (Exception e) {
            logger.error("Error parsing JSON response: {}", e.getMessage());
        }
        return testCases;
    }

    private List<TestStep> fetchTestSteps(int testCaseID) throws JSONException {
        List<TestStep> testSteps = new ArrayList<>();
        String endpoint = Config.BASE_URL + "/testcase/" + testCaseID + "/detail";
        // Send GET request to fetch test case details
        Response response = RestAssured.given()
                .header("Authorization", Config.AUTH_HEADER)
                .when()
                .get(endpoint)
                .then()
                .extract()
                .response();

        String responseBody = response.asString();
//        logger.info("Test case details: {}", responseBody);
        try {
            JSONObject jsonResponse = new JSONObject(responseBody);
            JSONArray steps = jsonResponse.getJSONArray("steps");
            JSONArray tags = jsonResponse.getJSONArray("tags");
            // Find if there is a tag with name "restapi"
            boolean hasRestApiTag = false;
            for (int i = 0; i < tags.length(); i++) {
                JSONObject tag = tags.getJSONObject(i);
                JSONObject tagDetails = tag.getJSONObject("tag");
                if (tagDetails.getString("name").equals("restapi")) {
                    hasRestApiTag = true;
                    break;
                }
            }
            if (hasRestApiTag) {
                for (int i = 0; i < steps.length(); i++) {
                    JSONObject step = steps.getJSONObject(i);
                    String stepDescription = step.getString("step");
                    testSteps.add(new TestStep(stepDescription));
                }
            }
        } catch (Exception e) {
            logger.error("Error parsing test steps response: {}", e.getMessage());
        }
        return testSteps;
    }

    private String[] extractTestCaseData(TestCase testCase, List<TestStep> testSteps) {
        String url = "", methodType = "", requestHeaders = "", requestBody = "", expectedStatusCode = "", responseBody = "";
        for (TestStep step : testSteps) {
            String description = step.getDescription();
            if (description.contains("URL:")) {
                url = description.split("URL:")[1].trim();
                if (url.contains("(Link:")) {// Remove "(Link: ..." from the URL if present
                    url = url.split("\\(Link:")[0].trim();
                }
            } else if (description.contains("Method Type:")) {
                methodType = description.split("Method Type:")[1].trim();
            } else if (description.contains("Request Headers:")) {
                requestHeaders = description.split("Request Headers:")[1].trim().replaceAll("\n", "");
            } else if (description.contains("Request Body:")) {
                requestBody = description.split("Request Body:")[1].trim().replaceAll("\n", "");
            } else if (description.contains("Validate Status Code:")) {
                expectedStatusCode = description.split("Validate Status Code:")[1].trim();
            } else if (description.contains("Response Body:")) {
                responseBody = description.split("Response Body:")[1].trim().replaceAll("\n", "");
            }
        }
//        return new String[]{String.valueOf(testCase.getId()), testCase.getKey(), url, methodType, requestBody, expectedStatusCode};
        return new String[]{testCase.getKey(), testCase.getTitle(), url, methodType, requestHeaders, requestBody, expectedStatusCode, responseBody};
    }

    private void writeDataToCSV(List<String[]> data) {
        try (CSVWriter writer = new CSVWriter(new FileWriter(new File(Config.CSV_FILE_PATH), false))) {
            writer.writeAll(data);
            logger.info("Test cases written to CSV successfully.");
        } catch (IOException e) {
            logger.error("Error writing CSV: {}", e.getMessage());
        }
    }
}