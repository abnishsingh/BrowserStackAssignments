package com.ncb.poc.ra.execute;

import com.ncb.poc.ra.config.Config;
import com.opencsv.CSVReader;
import com.opencsv.exceptions.CsvException;
import io.qameta.allure.Allure;
import io.qameta.allure.Description;
import io.qameta.allure.Feature;
import io.restassured.RestAssured;
import io.restassured.http.ContentType;
import io.restassured.path.json.JsonPath;
import io.restassured.response.Response;
import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;
import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;
import org.testng.Assert;
import org.testng.ITestContext;
import org.testng.ITestResult;
import org.testng.annotations.*;
import java.io.FileReader;
import java.io.IOException;
import java.util.*;
import java.util.stream.Collectors;

public class APITestRunner {

    private static final Logger logger = LogManager.getLogger(APITestRunner.class);
    private static String testCycleId;

    @BeforeSuite
    public void createTestCycle() throws JSONException {
//        JSONObject payload = new JSONObject();
//        payload.put("sourceIDs", new JSONArray().put(Config.SET_KEY));
//        payload.put("title", Config.CYCLE_NAME + Config.TIMESTAMP);
//        Response response = RestAssured.given()
//                .header("Authorization", Config.AUTH_HEADER)
//                .contentType(ContentType.JSON)
//                .body(payload.toString())
//                .post(Config.BASE_URL + "/testcycle/testset/create")
//                .then()
//                .extract()
//                .response();
//        testCycleId = response.jsonPath().getString("ID");
//        logger.info("Test Cycle Created: {}", testCycleId);
        // Fetch and store test cases in CSV
        TestCaseWriter extractor = new TestCaseWriter();
        extractor.processTestCases();
    }

    @DataProvider(name = "testCases")
    public Object[][] readTestCasesFromCSV() {
        List<Object[]> testCases = new ArrayList<>();
        try (CSVReader reader = new CSVReader(new FileReader(Config.CSV_FILE_PATH))) {
            List<String[]> allRows = reader.readAll();
            // Skip header row and filter only valid rows (with 7 columns)
            testCases = allRows.stream()
                    .skip(1)
                    .filter(row -> row.length == 8)
                    .peek(row -> logger.info("Loaded CSV row: {}", String.join(", ", row)))
                    .collect(Collectors.toList());
        } catch (IOException | CsvException e) {
            logger.error("Error reading CSV: {}", e.getMessage());
        }
        return testCases.toArray(new Object[0][]);
    }

    @Test(dataProvider = "testCases")
    @Feature("API Tests") // Groups tests in Allure
    @Description("Execute API Test Case")
    public void executeAPITest(String testCaseKey,String testCaseTitle,String url, String methodType,String requestHeaders, String requestBody, String expectedStatusCode,String expectedResponseBody, ITestContext context) throws JSONException {
        context.setAttribute("testCaseKey", testCaseKey);
        Allure.getLifecycle().updateTestCase(tc -> tc.setName(testCaseTitle));
        // Attach parameters to Allure
        Allure.parameter("Test Case Name", testCaseTitle);
        Allure.parameter("URL", url);
        Allure.parameter("Method Type", methodType);
        Allure.parameter("Request Headers", requestHeaders);
        Allure.parameter("Request Body", requestBody);
        Allure.parameter("Expected Status Code", expectedStatusCode);
        Allure.parameter("Expected Response Body", expectedResponseBody);

        logger.info("Executing Testcase:: {}", testCaseTitle);
        logger.info("TestCase Key: {}", testCaseKey);
        logger.info("URL: {}", url);
        logger.info("Method: {}", methodType);
        logger.info("Request Headers: {}", requestHeaders);
        logger.info("Request Body: {}", requestBody);
        logger.info("Expected Status Code: {}", expectedStatusCode);
        logger.info("Expected Response Body: {}", expectedResponseBody);

        if (methodType == null || methodType.trim().isEmpty()) {
            logger.info("Skipping test case due to missing method type.");
            return;  // Skip this test case
        }
        // Handle case where requestHeaders are missing or empty
        Map<String, String> headers = new HashMap<>();
        if (requestHeaders != null && !requestHeaders.trim().isEmpty()) {
            // Convert the JSON string to a JSONObject
            JSONObject requestHeadersJson = new JSONObject(requestHeaders);
            // Convert the JSONObject to a Map<String, String>
            Iterator<String> Hkeys = requestHeadersJson.keys(); // Get all keys
            while (Hkeys.hasNext()) {
                String key = Hkeys.next();
                String value = requestHeadersJson.getString(key); // Get corresponding value
                headers.put(key, value); // Add to the map
            }
        } else {
            logger.info("No request headers provided.");
        }
        Response response;
        switch (methodType.toUpperCase()) {

            case "GET":
                response = RestAssured.given().headers(headers).get(url);
                break;
            case "POST":
                response = RestAssured.given().headers(headers).body(requestBody).post(url);
                logger.info("Response Body: {}", response.getBody().asString());
                break;
            case "PUT":
                response = RestAssured.given().headers(headers).body(requestBody).when().put(url);
                logger.info("Response Body: {}", response.getBody().asString());
                break;
            case "PATCH":
                response = RestAssured.given().headers(headers).body(requestBody).when().patch(url);
                logger.info("Response Body: {}", response.getBody().asString());
                break;
            case "DELETE":
                response = RestAssured.given().headers(headers).when().delete(url);
                logger.info("Response Body: {}", response.getBody().asString());
                break;
            default:
                logger.error("Skipping test case due to unsupported method type: {}", methodType);
                return;
        }
        // Validate the status code if expectedStatusCode is provided
        if (expectedStatusCode != null && !expectedStatusCode.trim().isEmpty()) {
            int expectedCode = Integer.parseInt(expectedStatusCode);
            response.then().assertThat().statusCode(expectedCode);
        }
        if (expectedResponseBody != null && !expectedResponseBody.trim().isEmpty()) {
            try {
                JSONObject expectedJson = new JSONObject(expectedResponseBody);
                JsonPath actualJsonPath = response.jsonPath();
                Iterator<String> keys = expectedJson.keys();
                while (keys.hasNext()) {
                    String key = keys.next();
                    Object expectedValue = expectedJson.get(key);
                    Object actualValue = actualJsonPath.get(key);
                    logger.info("Validating Key: {}", key);
                    logger.info("Expected Value: {}", expectedValue);
                    logger.info("Actual Value: {}", actualValue);
                    Assert.assertEquals(actualValue, expectedValue, "Mismatch in key: " + key);
                }
            } catch (Exception e) {
                Assert.fail("Response Body Validation Failed: " + e.getMessage());
            }
        }


    }

    @AfterMethod
    public void updateTestCaseStatus(ITestResult result) {
//        String testCaseKey = (String) result.getTestContext().getAttribute("testCaseKey"); // Retrieve testCaseKey
//        String testCycleKey = testCycleId; // Use the global testCycleId
//        logger.info("Updating Test Case: {} in Test Cycle: {}", testCaseKey, testCycleKey);
//        String testRunStatus = result.isSuccess() ? "Passed" : "Failed"; // Determine status
//        List<String> comments = new ArrayList<>();
//
//        if (!result.isSuccess()) {
//            Throwable failureReason = result.getThrowable();
//            comments.add("Test failed: " + failureReason.getMessage());
//        } else {
//            comments.add("Test passed successfully.");
//        }
//        JSONObject payload = new JSONObject();
//        try {
//            payload.put("testRunStatus", testRunStatus);
//            payload.put("comments", new JSONArray(comments));
//            payload.put("ID", 1); // You may need to dynamically assign this based on your use case
//        } catch (JSONException e) {
//            e.printStackTrace();
//        }
//
//        logger.info("Payload: {}", payload.toString());
//
//        // Perform API request to update test case execution status
//        Response response = RestAssured.given()
//                .header("accept", "application/json;charset=utf-8")
//                .header("Authorization", Config.AUTH_HEADER)
//                .header("Content-Type", "application/json")
//                .body(payload.toString())
//                .post(Config.BASE_URL+"/testcycle/" + testCycleKey + "/testcase/" + testCaseKey + "/testrun")
//                .then()
//                .extract()
//                .response();
//
//        // Debugging response
//        logger.info("Update Response Status Code: {}", response.getStatusCode());
//        logger.info("Update Response Body: {}", response.getBody().asString());
//
//        if (response.getStatusCode() != 200) {
//            logger.error("Failed to update test case status for {}", testCaseKey);
//        } else {
//            logger.info("Test case {} updated successfully!", testCaseKey);
//        }
    }

    @AfterSuite
    public void closeTestCycle() throws JSONException {
//        JSONObject payload = new JSONObject();
//        payload.put("name", "CLOSED");
//        payload.put("value", true);
//        RestAssured.given()
//                .header("Authorization", Config.AUTH_HEADER)
//                .contentType(ContentType.JSON)
//                .body(payload.toString())
//                .put(Config.BASE_URL + "/testcycle/" + testCycleId + "/state");
//        logger.info("Test Cycle Closed: {}", testCycleId);
    }

}
