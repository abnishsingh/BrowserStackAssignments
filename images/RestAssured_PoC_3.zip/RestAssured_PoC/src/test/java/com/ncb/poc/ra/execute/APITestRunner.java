package com.ncb.poc.ra.execute;

import com.ncb.poc.ra.utils.ConfigReader;
import com.opencsv.CSVReader;
import com.opencsv.exceptions.CsvException;
import io.qameta.allure.Allure;
import io.qameta.allure.Description;
import io.qameta.allure.Feature;
import io.restassured.RestAssured;
import io.restassured.http.ContentType;
import io.restassured.path.json.JsonPath;
import io.restassured.response.Response;
import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;
import org.testng.Assert;
import org.testng.ITestContext;
import org.testng.ITestResult;
import org.testng.annotations.*;

import java.io.FileReader;
import java.io.IOException;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Date;
import java.util.Iterator;
import java.util.List;

public class APITestRunner {

    private static final String CSV_FILE_PATH = ConfigReader.getProperty("CSV_FILE_PATH");
    private static final String AUTH_HEADER = ConfigReader.getProperty("AUTH_HEADER");
    private static final String BASE_URL = ConfigReader.getProperty("BASE_URL");
    private static String testCycleId;

    @BeforeSuite
    public void createTestCycle() throws JSONException {
        String timestamp = new SimpleDateFormat("yyyyMMddHHmmss").format(new Date());
        JSONObject payload = new JSONObject();
        payload.put("sourceIDs", new JSONArray().put("NUETAF-TS-2"));
        payload.put("title", "Automated API Cycle - " + timestamp);
        Response response = RestAssured.given()
                .header("Authorization", AUTH_HEADER)
                .contentType(ContentType.JSON)
                .body(payload.toString())
                .post(BASE_URL + "/testcycle/testset/create")
                .then()
                .extract()
                .response();
        testCycleId = response.jsonPath().getString("ID");
        System.out.println("Test Cycle Created: " + testCycleId);
        // Fetch and store test cases in CSV
        TestCaseCSVWriter extractor = new TestCaseCSVWriter();
        extractor.processTestCases();
    }

    @DataProvider(name = "testCases")
    public Object[][] readTestCasesFromCSV() {
        List<Object[]> testCases = new ArrayList<>();
        try (CSVReader reader = new CSVReader(new FileReader(CSV_FILE_PATH))) {
            List<String[]> allRows = reader.readAll();
            boolean isHeader = true;
            for (String[] row : allRows) {
                if (isHeader) {
                    isHeader = false;
                    continue; // Skip header row
                }
                // Ensure each row has exactly 6 columns
                if (row.length == 7) {
                    testCases.add(row);
                } else {
                    System.err.println("Skipping invalid row: " + String.join(", ", row));
                }
            }
        } catch (IOException | CsvException e) {
            e.printStackTrace();
        }
        return testCases.toArray(new Object[0][]);
    }

    @Test(dataProvider = "testCases")
    @Feature("API Tests") // Groups tests in Allure
    @Description("Execute API Test Case")
    public void executeAPITest(String testCaseKey,String testCaseTitle,String url, String methodType, String requestBody, String expectedStatusCode,String expectedResponseBody, ITestContext context) {
        context.setAttribute("testCaseKey", testCaseKey);
        Allure.getLifecycle().updateTestCase(tc -> tc.setName(testCaseTitle));
        // Attach parameters to Allure
        Allure.parameter("Test Case Name", testCaseTitle);
        Allure.parameter("URL", url);
        Allure.parameter("Method Type", methodType);
        Allure.parameter("Request Body", requestBody);
        Allure.parameter("Expected Status Code", expectedStatusCode);
        Allure.parameter("Expected Response Body", expectedResponseBody);

        System.out.println("Executing API Test: " + testCaseTitle);
        System.out.println("URL: " + url);
        System.out.println("Method: " + methodType);
        System.out.println("Request Body: " + requestBody);
        System.out.println("Expected Status Code: " + expectedStatusCode);
        System.out.println("Expected Response Body: " + expectedResponseBody);
        if (methodType == null || methodType.trim().isEmpty()) {
            System.out.println("Skipping test case due to missing method type.");
            return;  // Skip this test case
        }
        Response response;
        switch (methodType.toUpperCase()) {
            case "GET":
                response = RestAssured.given().get(url);
                break;
            case "POST":
                response = RestAssured.given().header("Content-Type", "application/json").body(requestBody).post(url);
                System.out.println("Response Body: " + response.getBody().asString());
                break;
            case "PUT":
                response = RestAssured.given().header("Content-Type", "application/json").body(requestBody).when().put(url);
                System.out.println("Response Body: " + response.getBody().asString());
                break;
            case "PATCH":
                response = RestAssured.given().header("Content-Type", "application/json").body(requestBody).when().patch(url);
                System.out.println("Response Body: " + response.getBody().asString());
                break;
            case "DELETE":
                response = RestAssured.given().when().delete(url);
                System.out.println("Response Body: " + response.getBody().asString());
                break;
            default:
                System.out.println("Skipping test case due to unsupported method type: " + methodType);
                return;
        }
        // Validate the status code if expectedStatusCode is provided
        if (expectedStatusCode != null && !expectedStatusCode.trim().isEmpty()) {
            int expectedCode = Integer.parseInt(expectedStatusCode);
            response.then().assertThat().statusCode(expectedCode);
        }
        if (expectedResponseBody != null && !expectedResponseBody.trim().isEmpty()) {
            try {
                JSONObject expectedJson = new JSONObject(expectedResponseBody);
                JsonPath actualJsonPath = response.jsonPath();
                Iterator<String> keys = expectedJson.keys();
                while (keys.hasNext()) {
                    String key = keys.next();
                    Object expectedValue = expectedJson.get(key);
                    Object actualValue = actualJsonPath.get(key);
                    System.out.println("Validating Key: " + key);
                    System.out.println("Expected Value: " + expectedValue);
                    System.out.println("Actual Value: " + actualValue);
                    Assert.assertEquals(actualValue, expectedValue, "Mismatch in key: " + key);
                }
            } catch (Exception e) {
                Assert.fail("Response Body Validation Failed: " + e.getMessage());
            }
        }


    }

    @AfterMethod
    public void updateTestCaseStatus(ITestResult result) {
        String testCaseKey = (String) result.getTestContext().getAttribute("testCaseKey"); // Retrieve testCaseKey
        String testCycleKey = testCycleId; // Use the global testCycleId
        System.out.println(testCycleKey);
        String testRunStatus = result.isSuccess() ? "Passed" : "Failed"; // Determine status
        List<String> comments = new ArrayList<>();

        if (!result.isSuccess()) {
            Throwable failureReason = result.getThrowable();
            comments.add("Test failed: " + failureReason.getMessage());
        } else {
            comments.add("Test passed successfully.");
        }
        JSONObject payload = new JSONObject();
        try {
            payload.put("testRunStatus", testRunStatus);
            payload.put("comments", new JSONArray(comments));
            payload.put("ID", 1); // You may need to dynamically assign this based on your use case
        } catch (JSONException e) {
            e.printStackTrace();
        }

        // Debugging
        System.out.println("Updating Test Case: " + testCaseKey + " in Test Cycle: " + testCycleKey);
        System.out.println("Payload: " + payload.toString());

        // Perform API request to update test case execution status
        Response response = RestAssured.given()
                .header("accept", "application/json;charset=utf-8")
                .header("Authorization", AUTH_HEADER)
                .header("Content-Type", "application/json")
                .body(payload.toString())
                .post("https://tcms.aiojiraapps.com/aio-tcms/api/v1/project/10175/testcycle/" + testCycleKey + "/testcase/" + testCaseKey + "/testrun")
                .then()
                .extract()
                .response();

        // Debugging response
        System.out.println("Response Status Code: " + response.getStatusCode());
        System.out.println("Response Body: " + response.getBody().asString());

        if (response.getStatusCode() != 200) {
            System.out.println("Failed to update test case status for " + testCaseKey);
        } else {
            System.out.println("Test case " + testCaseKey + " updated successfully!");
        }
    }

    @AfterSuite
    public void closeTestCycle() throws JSONException {
        JSONObject payload = new JSONObject();
        payload.put("name", "CLOSED");
        payload.put("value", true);
        RestAssured.given()
                .header("Authorization", AUTH_HEADER)
                .contentType(ContentType.JSON)
                .body(payload.toString())
                .put(BASE_URL + "/testcycle/" + testCycleId + "/state");
        System.out.println("Test Cycle Closed: " + testCycleId);
    }

}
