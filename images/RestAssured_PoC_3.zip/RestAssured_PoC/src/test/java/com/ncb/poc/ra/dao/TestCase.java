package com.ncb.poc.ra.dao;

public  class TestCase {
    private int id;
    private String testCaseKey;
    private String title;
    private String description;
    private boolean selected;

    public TestCase(int id, String testCaseKey,String title, String description, boolean selected) {
        this.id = id;
        this.testCaseKey = testCaseKey;
        this.title = title;
        this.description = description;
        this.selected = selected;
    }

    public int getId() {
        return id;
    }

    public String getTitle() {
        return title;
    }

    public String getDescription() {
        return description;
    }

    public boolean isSelected() {
        return selected;
    }

    public void setSelected(boolean selected) {
        this.selected = selected;
    }

    public String getKey() {
        return testCaseKey;
    }
}
